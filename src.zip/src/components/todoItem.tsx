import React, { useState } from 'react';
import { useSetRecoilState } from 'recoil';
import { todoListState, TodoItemType } from '../atoms/todoListAtom';

const TodoItem = ({ item }: { item: TodoItemType }) => {
  const setTodoList = useSetRecoilState(todoListState);
  const [isEditing, setIsEditing] = useState(false);
  const [newText, setNewText] = useState(item.text);

  const updateTodo = () => {
    if (!newText.trim()) {
      setNewText(item.text);
      setIsEditing(false);
      return;
    }
    setTodoList((oldList) =>
      oldList.map((todo) =>
        todo.id === item.id ? { ...todo, text: newText.trim() } : todo
      )
    );
    setIsEditing(false);
  };

  const cancelEdit = () => {
    setNewText(item.text);
    setIsEditing(false);
  };

  const deleteTodo = () => {
    setTodoList((oldList) => oldList.filter((todo) => todo.id !== item.id));
  };

  const toggleComplete = () => {
    setTodoList((oldList) =>
      oldList.map((todo) =>
        todo.id === item.id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  const getPriorityConfig = (priority: string) => {
    switch (priority) {
      case 'high': 
        return { color: '#ef4444', bgColor: '#fef2f2', label: '🔴', text: '높음' };
      case 'medium': 
        return { color: '#f59e0b', bgColor: '#fffbeb', label: '🟡', text: '중간' };
      case 'low': 
        return { color: '#10b981', bgColor: '#f0fdf4', label: '🟢', text: '낮음' };
      default: 
        return { color: '#6b7280', bgColor: '#f9fafb', label: '⚪', text: '기본' };
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      updateTodo();
    } else if (e.key === 'Escape') {
      cancelEdit();
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return '오늘';
    if (diffDays === 1) return '어제';
    if (diffDays < 7) return `${diffDays}일 전`;
    return date.toLocaleDateString('ko-KR', { month: 'short', day: 'numeric' });
  };

  const priorityConfig = getPriorityConfig(item.priority);

  return (
    <div style={{
      ...styles.item,
      borderLeft: `4px solid ${priorityConfig.color}`,
      backgroundColor: item.completed ? '#f8fafc' : '#ffffff',
      opacity: item.completed ? 0.8 : 1,
    }}>
      {/* 체크박스와 텍스트 영역 */}
      <div style={styles.mainContent}>
        <div style={styles.checkboxArea}>
          <button
            onClick={toggleComplete}
            style={{
              ...styles.checkbox,
              backgroundColor: item.completed ? priorityConfig.color : 'transparent',
              borderColor: priorityConfig.color,
            }}
          >
            {item.completed && <span style={styles.checkmark}>✓</span>}
          </button>
        </div>

        <div style={styles.contentArea}>
          {isEditing ? (
            <input
              value={newText}
              onChange={(e) => setNewText(e.target.value)}
              onKeyDown={handleKeyPress}
              onBlur={updateTodo}
              style={styles.editInput}
              autoFocus
            />
          ) : (
            <div style={styles.textContent}>
              <span style={{
                ...styles.todoText,
                textDecoration: item.completed ? 'line-through' : 'none',
                color: item.completed ? '#94a3b8' : '#1e293b',
              }}>
                {item.text}
              </span>
              <div style={styles.metadata}>
                <span style={{
                  ...styles.priorityBadge,
                  backgroundColor: priorityConfig.bgColor,
                  color: priorityConfig.color,
                }}>
                  {priorityConfig.label} {priorityConfig.text}
                </span>
                <span style={styles.dateText}>
                  {formatDate(item.createdAt)}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 액션 버튼들 */}
      <div style={styles.actionButtons}>
        {isEditing ? (
          <>
            <button onClick={updateTodo} style={{...styles.actionBtn, ...styles.saveBtn}}>
              💾
            </button>
            <button onClick={cancelEdit} style={{...styles.actionBtn, ...styles.cancelBtn}}>
              ❌
            </button>
          </>
        ) : (
          <>
            <button 
              onClick={() => setIsEditing(true)} 
              style={{...styles.actionBtn, ...styles.editBtn}}
              title="수정"
            >
              ✏️
            </button>
            <button 
              onClick={deleteTodo} 
              style={{...styles.actionBtn, ...styles.deleteBtn}}
              title="삭제"
            >
              🗑️
            </button>
          </>
        )}
      </div>
    </div>
  );
};

const styles: { [key: string]: React.CSSProperties } = {
  item: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '16px',
    borderRadius: '12px',
    border: '1px solid #e2e8f0',
    transition: 'all 0.2s ease',
    cursor: 'pointer',
    minHeight: '70px',
  },
  mainContent: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '12px',
    flex: 1,
    minWidth: 0,
  },
  checkboxArea: {
    display: 'flex',
    alignItems: 'center',
    paddingTop: '2px',
  },
  checkbox: {
    width: '20px',
    height: '20px',
    borderRadius: '4px',
    border: '2px solid',
    background: 'transparent',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'all 0.2s ease',
    padding: 0,
  },
  checkmark: {
    color: 'white',
    fontSize: '12px',
    fontWeight: 'bold',
  },
  contentArea: {
    flex: 1,
    minWidth: 0,
  },
  textContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: '6px',
  },
  todoText: {
    fontSize: '16px',
    fontWeight: '500',
    lineHeight: '1.4',
    wordBreak: 'break-word',
    margin: 0,
  },
  metadata: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    flexWrap: 'wrap',
  },
  priorityBadge: {
    fontSize: '12px',
    fontWeight: '600',
    padding: '2px 6px',
    borderRadius: '6px',
    border: '1px solid currentColor',
  },
  dateText: {
    fontSize: '12px',
    color: '#94a3b8',
    fontWeight: '500',
  },
  editInput: {
    width: '100%',
    padding: '8px 12px',
    fontSize: '16px',
    borderRadius: '8px',
    border: '2px solid #3b82f6',
    backgroundColor: '#ffffff',
    outline: 'none',
    fontFamily: 'inherit',
  },
  actionButtons: {
    display: 'flex',
    gap: '4px',
    flexShrink: 0,
  },
  actionBtn: {
    width: '32px',
    height: '32px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '14px',
    transition: 'all 0.2s ease',
    opacity: 0.7,
  },
  editBtn: {
    backgroundColor: '#f1f5f9',
    color: '#475569',
  },
  deleteBtn: {
    backgroundColor: '#fef2f2',
    color: '#dc2626',
  },
  saveBtn: {
    backgroundColor: '#f0f9ff',
    color: '#0369a1',
  },
  cancelBtn: {
    backgroundColor: '#fef2f2',
    color: '#dc2626',
  },
};

export default TodoItem;